import { Link } from 'react-router-dom'

const Error = () => {
  return (
    <>
      <h6>404 Page not found</h6>
     <Link to='/home'>-home-</Link>
    </>
  )
}

export default Error