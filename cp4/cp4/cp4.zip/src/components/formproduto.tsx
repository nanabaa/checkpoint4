import './produto'


function formproduto(){

    const inputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target
    Produto.SetProduto({
    })
}

}
export default formproduto