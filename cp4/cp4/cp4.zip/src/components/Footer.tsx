const Footer = () => {
  return (
    <footer>
      <a>Ana Clara de Oliveira Nascimento RM561957 - Anabelle Rosseto Rodrigues RM564526</a>
    </footer>
  )
}

export default Footer